var flip = document.querySelector('.book-content');
var uno = document.querySelectorAll('.book');

var contZindex = 2;
var customZindex = 1;

var DEBUG_CTA = true;

var currentFlip = 0;
var totalFlips = 3;
var pageIndicator = document.getElementById('pageIndicator');
var currentPageEl = document.getElementById('currentPage');

function setTotalFlips(count) {
    totalFlips = count;

    const totalPagesEl = document.getElementById('totalPages');
    if (totalPagesEl && totalPagesEl.textContent !== String(count)) {
        totalPagesEl.textContent = count;
    }
}

if (typeof window !== 'undefined') {
    window.setTotalFlips = setTotalFlips;
    window.totalFlips = totalFlips;
}

function updatePageIndicator(flip) {
	currentFlip = flip;
	if (currentPageEl) {
		currentPageEl.textContent = currentFlip;
	}

	if (pageIndicator) {
		if (currentFlip >= 1) {

			setTimeout(function(){
				pageIndicator.classList.add('show');
			}, 600);
		} else {

			pageIndicator.classList.remove('show');
		}
	}
}

function shiftBookFinal(direction, delay) {
	delay = delay || 500;
	setTimeout(function(){
		if (direction === 'right') {

			flip.classList.remove("trnsf-reset", "trnsf");
			flip.classList.add("trnsf-final");
		} else if (direction === 'left') {

			flip.classList.remove("trnsf-final", "trnsf-reset");
			flip.classList.add("trnsf");
		}
	}, delay);
}

var bookContent = document.querySelector('.book-content');
var doubleHeart = document.getElementById('doubleHeart');
var doubleHeartGlow = document.getElementById('doubleHeartGlow');
var giftBox = document.getElementById('giftBox');
var noFinalGiftImg = document.getElementById('noFinalGiftImg');
var giftBoxGlow = document.getElementById('giftBoxGlow');
var doubleHeartOriginalSrc = doubleHeart ? doubleHeart.getAttribute('src') : null;
var finalCtaTimers = [];
var dropAnim = null;

var leftCupid = document.getElementById('leftCupid');
var rightCupid = document.getElementById('rightCupid');
var leftCupidAnim = null;
var rightCupidAnim = null;
var cupidsConverged = false;
var doubleHeartDropped = false;

function ctaSetTimeout(fn, ms) {
	var id = setTimeout(fn, ms);
	finalCtaTimers.push(id);
	return id;
}
function clearFinalCtaTimers() {
	while (finalCtaTimers.length) {
		clearTimeout(finalCtaTimers.pop());
	}
}

function clearDropAnim() {
	try {
		if (dropAnim) dropAnim.cancel();
	} catch (e) {}
	dropAnim = null;
}

function clearCupidsAnims() {
	try {
		if (leftCupidAnim) leftCupidAnim.cancel();
		if (rightCupidAnim) rightCupidAnim.cancel();
	} catch (e) {}
	leftCupidAnim = null;
	rightCupidAnim = null;
	cupidsConverged = false;
}

function resetFinalCta() {
	clearFinalCtaTimers();
	clearDropAnim();
	clearCupidsAnims();
	cupidsConverged = false;
	doubleHeartDropped = false;

	if (doubleHeart) {
		doubleHeart.classList.remove('cta-drop', 'cta-heart', 'fade-out', 'show');

		doubleHeart.style.opacity = '';
		doubleHeart.style.transition = '';
		doubleHeart.style.display = '';
		if (doubleHeartOriginalSrc) doubleHeart.setAttribute('src', doubleHeartOriginalSrc);
	}
	if (doubleHeartGlow) {
		doubleHeartGlow.classList.remove('show');
		doubleHeartGlow.style.display = 'none';
	}

	if (leftCupid) {
		leftCupid.style.display = '';
		leftCupid.style.left = '';
		leftCupid.style.top = '';
		leftCupid.style.right = '';
		leftCupid.style.width = '';
		leftCupid.style.height = '';
		leftCupid.style.transform = '';
		leftCupid.style.transition = '';
		leftCupid.style.opacity = '';
		leftCupid.classList.remove('cupid-converge', 'cupid-fade-out');
	}
	if (rightCupid) {
		rightCupid.style.display = '';
		rightCupid.style.left = '';
		rightCupid.style.top = '';
		rightCupid.style.right = '';
		rightCupid.style.width = '';
		rightCupid.style.height = '';
		rightCupid.style.transform = '';
		rightCupid.style.transition = '';
		rightCupid.style.opacity = '';
		rightCupid.classList.remove('cupid-converge', 'cupid-fade-out');
	}

	if (giftBox) {
		giftBox.style.display = 'none';
		giftBox.classList.remove('show');
		giftBox.style.opacity = '';
		giftBox.style.transform = '';
		giftBox.style.transition = '';
	}
	if (noFinalGiftImg) {
		noFinalGiftImg.style.display = 'none';
		noFinalGiftImg.classList.remove('show');
		noFinalGiftImg.style.opacity = '';
		noFinalGiftImg.style.transform = '';
		noFinalGiftImg.style.transition = '';
		noFinalGiftImg.style.position = '';
		noFinalGiftImg.style.top = '';
		noFinalGiftImg.style.left = '';
		noFinalGiftImg.style.width = '';
		noFinalGiftImg.style.zIndex = '';
	}
	if (giftBoxGlow) {
		giftBoxGlow.style.display = 'none';
		giftBoxGlow.classList.remove('show');
		giftBoxGlow.style.opacity = '';
	}

	document.body.classList.remove('final-cta');
}

function showGiftBox() {

	var hasFinalGift = typeof window.hasFinalGift !== 'undefined' ? window.hasFinalGift : true;

	if (hasFinalGift && giftBox) {

		giftBox.style.display = 'block';
		giftBox.style.position = 'fixed';
		giftBox.style.top = '50%';
		giftBox.style.left = '50%';
		giftBox.style.width = '320px';
		giftBox.style.height = 'auto';
		giftBox.style.zIndex = '120';
		giftBox.style.opacity = '0';
		giftBox.style.transform = 'translate(-50%, -50%) scale(0.5)';
		giftBox.style.transition = 'none';
		giftBox.style.cursor = 'pointer';
		giftBox.style.pointerEvents = 'auto';
		void giftBox.offsetWidth;

		giftBox.style.transition = 'opacity 1.5s ease, transform 1.5s cubic-bezier(0.34, 1.56, 0.64, 1)';
		requestAnimationFrame(function(){
			requestAnimationFrame(function(){
				ctaSetTimeout(function(){
					giftBox.classList.add('show');
					giftBox.style.opacity = '1';
					giftBox.style.transform = 'translate(-50%, -50%) scale(1)';
				}, 50);
			});
		});

		if (giftBoxGlow) {
			giftBoxGlow.style.display = 'block';
			giftBoxGlow.style.position = 'fixed';
			giftBoxGlow.style.top = '50%';
			giftBoxGlow.style.left = '50%';
			giftBoxGlow.style.zIndex = '119';
			giftBoxGlow.style.opacity = '0';
			giftBoxGlow.style.transition = 'opacity 0.8s ease';
			void giftBoxGlow.offsetWidth;
			ctaSetTimeout(function(){
				giftBoxGlow.classList.add('show');
				giftBoxGlow.style.opacity = '1';
			}, 50);
		}
		return;
	}

	if (noFinalGiftImg) {
		noFinalGiftImg.style.display = 'block';
		noFinalGiftImg.style.position = 'fixed';
		noFinalGiftImg.style.top = '50%';
		noFinalGiftImg.style.left = '50%';
		noFinalGiftImg.style.width = 'min(520px, 85vw)';
		noFinalGiftImg.style.height = 'auto';
		noFinalGiftImg.style.zIndex = '120';
		noFinalGiftImg.style.opacity = '0';
		noFinalGiftImg.style.transform = 'translate(-50%, -50%) scale(0.5)';
		noFinalGiftImg.style.transition = 'none';
		noFinalGiftImg.style.pointerEvents = 'none';
		void noFinalGiftImg.offsetWidth;

		noFinalGiftImg.style.transition = 'opacity 1.5s ease, transform 1.5s cubic-bezier(0.34, 1.56, 0.64, 1)';
		requestAnimationFrame(function(){
			requestAnimationFrame(function(){
				ctaSetTimeout(function(){
					noFinalGiftImg.classList.add('show');
					noFinalGiftImg.style.opacity = '1';
					noFinalGiftImg.style.transform = 'translate(-50%, -50%) scale(1)';
				}, 50);
			});
		});
	}
}

function startCupidsConverge() {
	if (!leftCupid || !rightCupid) return;

	clearCupidsAnims();

	var leftRect = leftCupid.getBoundingClientRect();
	var rightRect = rightCupid.getBoundingClientRect();

	var centerX = window.innerWidth / 2;
	var centerY = window.innerHeight / 2;

	var leftDx = centerX - leftRect.left - leftRect.width / 2;
	var leftDy = centerY - leftRect.top - leftRect.height / 2;

	var rightDx = centerX - rightRect.left - rightRect.width / 2;
	var rightDy = centerY - rightRect.top - rightRect.height / 2;

	leftCupid.style.left = leftRect.left + 'px';
	leftCupid.style.top = leftRect.top + 'px';
	leftCupid.style.right = '';
	leftCupid.style.width = leftRect.width + 'px';
	leftCupid.style.height = leftRect.height + 'px';
	leftCupid.style.transform = 'translate3d(0,0,0)';
	leftCupid.style.transition = 'none';
	leftCupid.classList.add('cupid-converge');
	void leftCupid.offsetWidth;

	rightCupid.style.right = '';
	rightCupid.style.left = rightRect.left + 'px';
	rightCupid.style.top = rightRect.top + 'px';
	rightCupid.style.width = rightRect.width + 'px';
	rightCupid.style.height = rightRect.height + 'px';
	rightCupid.style.transform = 'translate3d(0,0,0)';
	rightCupid.style.transition = 'none';
	rightCupid.classList.add('cupid-converge');
	void rightCupid.offsetWidth;

	var animDuration = 1800;
	var animEasing = 'cubic-bezier(0.16, 1, 0.3, 1)';

	try {

		leftCupidAnim = leftCupid.animate(
			[
				{ transform: 'translate3d(0,0,0)' },
				{ transform: 'translate3d(' + leftDx + 'px,' + leftDy + 'px,0)' }
			],
			{ duration: animDuration, easing: animEasing, fill: 'forwards' }
		);

		rightCupidAnim = rightCupid.animate(
			[
				{ transform: 'translate3d(0,0,0)' },
				{ transform: 'translate3d(' + rightDx + 'px,' + rightDy + 'px,0)' }
			],
			{ duration: animDuration, easing: animEasing, fill: 'forwards' }
		);

		var completedCount = 0;
		var checkAllComplete = function() {
			completedCount++;
			if (completedCount === 2) {
				cupidsConverged = true;

				leftCupid.style.left = '';
				leftCupid.style.top = '';
				leftCupid.style.width = '';
				leftCupid.style.height = '';
				leftCupid.style.transform = '';
				leftCupid.style.transition = '';

				rightCupid.style.left = '';
				rightCupid.style.top = '';
				rightCupid.style.width = '';
				rightCupid.style.height = '';
				rightCupid.style.transform = '';
				rightCupid.style.transition = '';

				leftCupid.style.left = '50%';
				leftCupid.style.top = '50%';
				leftCupid.style.transform = 'translate(-50%, -50%)';

				rightCupid.style.left = '50%';
				rightCupid.style.top = '50%';
				rightCupid.style.transform = 'translate(-50%, -50%)';

				leftCupidAnim = null;
				rightCupidAnim = null;

				checkAndFadeOutAll();
			}
		};

		leftCupidAnim.onfinish = checkAllComplete;
		rightCupidAnim.onfinish = checkAllComplete;
	} catch (e) {

		if (DEBUG_CTA) console.warn('cupids converge WAAPI failed, using fallback:', e);
		cupidsConverged = true;

		checkAndFadeOutAll();
	}
}

function checkAndFadeOutAll() {

	if (cupidsConverged && doubleHeartDropped && !dropAnim) {

		fadeOutAllTogether();
	}
}

function fadeOutAllTogether() {

	var fadeDuration = 800;

	if (leftCupid) {
		leftCupid.style.transition = 'opacity ' + (fadeDuration / 1000) + 's ease';
		leftCupid.style.opacity = '0';
		leftCupid.classList.add('cupid-fade-out');
	}
	if (rightCupid) {
		rightCupid.style.transition = 'opacity ' + (fadeDuration / 1000) + 's ease';
		rightCupid.style.opacity = '0';
		rightCupid.classList.add('cupid-fade-out');
	}
	if (doubleHeart) {
		doubleHeart.style.transition = 'opacity ' + (fadeDuration / 1000) + 's ease';
		doubleHeart.style.opacity = '0';
	}
	if (doubleHeartGlow) {
		doubleHeartGlow.style.transition = 'opacity ' + (fadeDuration / 1000) + 's ease';
		doubleHeartGlow.style.opacity = '0';
	}

	ctaSetTimeout(function(){
		if (leftCupid) {
			leftCupid.style.display = 'none';
		}
		if (rightCupid) {
			rightCupid.style.display = 'none';
		}
		if (doubleHeart) {
			doubleHeart.style.display = 'none';
		}
		if (doubleHeartGlow) {
			doubleHeartGlow.style.display = 'none';
		}

		showGiftBox();
	}, fadeDuration + 50);
}

function startFinalCtaDrop() {
	if (!doubleHeart) return;
	document.body.classList.add('final-cta');

	clearFinalCtaTimers();
	clearDropAnim();
	doubleHeart.classList.remove('cta-drop', 'cta-gift', 'cta-heart', 'fade-out', 'show');
	if (doubleHeartOriginalSrc) doubleHeart.setAttribute('src', doubleHeartOriginalSrc);

	doubleHeart.style.opacity = '';
	doubleHeart.style.transition = '';

	var rect = doubleHeart.getBoundingClientRect();
	var targetLeft = (window.innerWidth - rect.width) / 2;
	var targetTop = (window.innerHeight - rect.height) / 2;
	var dx = targetLeft - rect.left;
	var dy = targetTop - rect.top;

	doubleHeart.style.left = rect.left + 'px';
	doubleHeart.style.top = rect.top + 'px';
	doubleHeart.style.width = rect.width + 'px';
	doubleHeart.style.height = rect.height + 'px';
	doubleHeart.style.transform = 'translate3d(0,0,0)';
	doubleHeart.style.transition = 'none';
	void doubleHeart.offsetWidth;

	try {
		dropAnim = doubleHeart.animate(
			[
				{ transform: 'translate3d(0,0,0)' },
				{ transform: 'translate3d(' + dx + 'px,' + dy + 'px,0)' }
			],
			{ duration: 1700, easing: 'cubic-bezier(0.16, 1, 0.3, 1)', fill: 'forwards' }
		);
		dropAnim.onfinish = function(){

			doubleHeart.style.left = '';
			doubleHeart.style.top = '';
			doubleHeart.style.width = '';
			doubleHeart.style.height = '';
			doubleHeart.style.transform = '';
			doubleHeart.style.transition = '';
			clearDropAnim();

			doubleHeartDropped = true;

			doubleHeart.style.left = '50%';
			doubleHeart.style.top = '50%';
			doubleHeart.style.transform = 'translate(-50%, -50%)';
			doubleHeart.classList.add('cta-heart');

			checkAndFadeOutAll();
		};
	} catch (e) {

		if (DEBUG_CTA) console.warn('drop(slide) WAAPI failed, using fallback:', e);
		doubleHeartDropped = true;

		if (doubleHeart) {
			doubleHeart.style.left = '50%';
			doubleHeart.style.top = '50%';
			doubleHeart.style.transform = 'translate(-50%, -50%)';
			doubleHeart.classList.add('cta-heart');
		}
		checkAndFadeOutAll();
	}
}

if (giftBox) {
	giftBox.addEventListener('click', function(){
		if (typeof window.hasFinalGift !== 'undefined' && !window.hasFinalGift) return;
		loadFinalScreen();
	});
}

function startLoadingProgress() {
	var progressFill = document.getElementById('loadingProgressFill');
	if (!progressFill) return;

	progressFill.style.width = '0%';

	var progress = 0;
	var progressInterval = setInterval(function() {
		progress += Math.random() * 30 + 20;
		if (progress > 90) {
			progress = 90;
			clearInterval(progressInterval);
		}
		progressFill.style.width = progress + '%';
	}, 30);

	window.loadingProgressInterval = progressInterval;
}

function completeLoadingProgress() {
	var progressFill = document.getElementById('loadingProgressFill');
	if (progressFill) {

		progressFill.style.width = '100%';

		if (window.loadingProgressInterval) {
			clearInterval(window.loadingProgressInterval);
			window.loadingProgressInterval = null;
		}
	}
}

function loadFinalScreen() {
	var finalScreen = document.getElementById('finalScreen');
	var loadingScreen = document.getElementById('finalLoadingScreen');
	if (!finalScreen) return;

	if (loadingScreen) {
		loadingScreen.style.display = 'flex';
		setTimeout(function(){
			loadingScreen.classList.add('show');

			startLoadingProgress();
		}, 30);
	}

	var introScreen = document.getElementById('introScreen');
	var secondScreen = document.getElementById('secondScreen');
	if (introScreen) introScreen.style.display = 'none';
	if (secondScreen) secondScreen.style.display = 'none';

	if (!window.dataMemoryHeartLoveLoom) {
		window.dataMemoryHeartLoveLoom = {
			"template": "birthday-v2",
			"data": {
				"title": "Feliz Mes, Mi Amor Eterno",
				"messages": [],
				"images": ["./assets/images/final/anh.jpg"],
				"heartColor": "#ff1493"
			}
		};
	}

	var originalAppendChild = document.body.appendChild;
	var canvasAppended = false;
	var canvasElement = null;

	document.body.appendChild = function(element) {

		if (element.tagName === 'CANVAS' && !canvasAppended) {
			canvasAppended = true;
			canvasElement = element;

			element.style.position = 'fixed';
			element.style.top = '0';
			element.style.left = '0';
			element.style.width = '100%';
			element.style.height = '100%';
			element.style.zIndex = '1';
			element.style.display = 'block';
			finalScreen.appendChild(element);
			return element;
		}

		return originalAppendChild.call(document.body, element);
	};

	loadFinalJS();

	function loadFinalJS() {

		var finalScript = document.createElement('script');
		finalScript.type = 'module';
		finalScript.src = './final_gift/final.js?v=' + (window.SWEET_ASSET_VERSION || '1');

		var scriptLoadTimeout = setTimeout(function() {
			alert('Hiệu ứng 3D đang tải chậm. Vui lòng kiểm tra kết nối mạng và thử lại.');
		}, 15000);

		finalScript.onload = function() {
			clearTimeout(scriptLoadTimeout);

			if (canvasAppended) {
				document.body.appendChild = originalAppendChild;
			}

			if (canvasElement && window.innerWidth && window.innerHeight) {

				var canvas = finalScreen.querySelector('canvas');
				if (canvas && canvas.width !== window.innerWidth) {

					window.dispatchEvent(new Event('resize'));
				}
			}

			completeLoadingProgress();

			if (loadingScreen) {
				loadingScreen.classList.remove('show');
				loadingScreen.style.display = 'none';
			}
		};

		finalScript.onerror = function(e) {
			clearTimeout(scriptLoadTimeout);

			document.body.appendChild = originalAppendChild;

			var errorMsg = 'Không thể tải hiệu ứng 3D.\n\n';
			errorMsg += 'Nguyên nhân có thể:\n';
			errorMsg += '- Kết nối mạng yếu\n';
			errorMsg += '- Trình duyệt chặn script\n';
			errorMsg += '- Phiên bản iOS/Safari quá cũ\n\n';
			errorMsg += 'Vui lòng:\n';
			errorMsg += '1. Kiểm tra kết nối WiFi/4G\n';
			errorMsg += '2. Tải lại trang (kéo xuống)\n';
			errorMsg += '3. Thử trình duyệt khác (Chrome/Safari)';

			alert(errorMsg);
		};

		document.body.appendChild(finalScript);
	}

	finalScreen.style.display = 'block';
	finalScreen.classList.add('is-visible');
	finalScreen.setAttribute('aria-hidden', 'false');

	console.log('✓ finalScreen hiển thị:', finalScreen.style.display, finalScreen.classList.contains('is-visible'));
}

function showFinalCta(show, delay) {
	delay = delay || 0;
	setTimeout(function(){
		if (show) {
			clearFinalCtaTimers();

			if (pageIndicator) {
				pageIndicator.classList.remove('show');
			}

			if (bookContent) {
				bookContent.classList.add('hide-for-gift');

				var started = false;
				var startDropOnce = function(){
					if (started) return;
					started = true;

					startCupidsConverge();
					startFinalCtaDrop();
				};
				var onEnd = function(ev){
					if (ev && ev.propertyName && ev.propertyName !== 'opacity') return;
					bookContent.removeEventListener('transitionend', onEnd);
					startDropOnce();
				};
				bookContent.addEventListener('transitionend', onEnd);

				ctaSetTimeout(function(){
					bookContent.removeEventListener('transitionend', onEnd);
					startDropOnce();
				}, 900);
			} else {

				startCupidsConverge();
				startFinalCtaDrop();
			}
		} else {

			resetFinalCta();

			setTimeout(function(){
				if (bookContent) bookContent.classList.remove('hide-for-gift');

				if (pageIndicator) {
					pageIndicator.classList.add('show');
				}
			}, 850);
		}
	}, delay);
}

function initializeBookFlip() {

	uno = document.querySelectorAll('.book');
	flip = document.querySelector('.book-content');

	contZindex = 2;
	customZindex = 1;

	for (var i = 0; i < uno.length; i++) {
		uno[i].style.zIndex = customZindex;
		customZindex--;

		uno[i].addEventListener('click', function(e){

			var tgt = e.target;
			var unoThis = this;
			var frontEl = tgt.closest && tgt.closest('.face-front');
			var backEl = tgt.closest && tgt.closest('.face-back');
			var portadaEl = tgt.closest && tgt.closest('#portada');
			var trsfEl = tgt.closest && tgt.closest('#trsf');
			var portadaBackEl = unoThis.querySelector('#portada-back');

			unoThis.style.zIndex = contZindex;
			contZindex++;

			if (frontEl && unoThis.contains(frontEl)) {
				unoThis.style.zIndex = contZindex;
				contZindex +=20;
				setTimeout(function(){
					unoThis.style.transform = 'rotateY(-180deg)';

					if (portadaBackEl) {

						shiftBookFinal('right', 500);

						showFinalCta(true, 1000);
					} else {

						var newFlip = currentFlip + 1;
						if (newFlip <= totalFlips) {
							updatePageIndicator(newFlip);
						}
					}
				}, 500);
			}
			if (backEl && unoThis.contains(backEl)) {
				unoThis.style.zIndex = contZindex;
				contZindex +=20;

				var isPortadaBack = tgt.closest && tgt.closest('#portada-back');
				if (isPortadaBack) {
					showFinalCta(false, 0);
				}

				setTimeout(function(){
					unoThis.style.transform = 'rotateY(0deg)';

					if (isPortadaBack) {
						shiftBookFinal('left', 500);

						updatePageIndicator(totalFlips);
					} else {

						var newFlip = currentFlip - 1;
						if (newFlip >= 0) {
							updatePageIndicator(newFlip);
						}
					}
				}, 500);
			}

			if (portadaEl) {
				flip.classList.remove("trnsf-reset");
				flip.classList.add("trnsf");

				updatePageIndicator(0);
			}
			if (trsfEl) {
				flip.classList.remove("trnsf");
				flip.classList.add("trnsf-reset");

				updatePageIndicator(1);
			}

		});
	}
}

function reinitializeBookFlip() {
	initializeBookFlip();
}

if (typeof window !== 'undefined') {
	window.reinitializeBookFlip = reinitializeBookFlip;
}

initializeBookFlip();
